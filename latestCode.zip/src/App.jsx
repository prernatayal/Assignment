// import Dashboard from './App/dashboard'
// import Login from './App/login'
import SignUp from './App/signup'

function App() {

  return (
    <>
      <SignUp /> 
      {/* <Login /> */}
      {/* <Dashboard /> */}
    </>
  )
}

export default App
